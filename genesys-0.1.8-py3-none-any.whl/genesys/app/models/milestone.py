from sqlalchemy_utils import UUIDType

from genesys.app import db
from genesys.app.models.serializer import SerializerMixin
from genesys.app.models.base import BaseMixin
from genesys.app.utils import fields


class Milestone(db.Model, BaseMixin, SerializerMixin):
    """
    Allow to set a milestone date to the production schedule.
    """

    date = db.Column(db.Date())
    name = db.Column(db.String(40), nullable=False)

    project_id = db.Column(
        UUIDType(binary=False), db.ForeignKey("project.id"), index=True
    )

    svn_revision = db.Column(db.Integer(), nullable=False)


    def present(self):
        return fields.serialize_dict(
            {
                "id": self.id,
                "date": self.date,
                "name": self.name,
                "project_id": self.project_id,
                "svn_revision": self.svn_revision,
            }
        )
