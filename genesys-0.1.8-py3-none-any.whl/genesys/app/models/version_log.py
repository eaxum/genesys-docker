from genesys.app.models.base import BaseMixin
from genesys.app import db
from genesys.app.models.serializer import SerializerMixin
from sqlalchemy_utils import UUIDType

class VersionLog(db.Model, BaseMixin, SerializerMixin):
    """
    Describes a production the studio works on.
    """
    name = db.Column(db.String(80), nullable=False, unique=True, index=True)
    file_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("file.id"),
        index=True
    )
    svn_revision = db.Column(db.Integer(), nullable=False)
    comment = db.Column(db.String(80), nullable=False, unique=True, index=True)
    auther = db.Column(db.String(80), nullable=False, unique=True, index=True)
    date = db.Column(db.DateTime, nullable=False, unique=True, index=True)


