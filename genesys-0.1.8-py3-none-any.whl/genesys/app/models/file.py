from genesys.app.models.base import BaseMixin
from genesys.app import db
from genesys.app.models.serializer import SerializerMixin
from sqlalchemy_utils import UUIDType

class File(db.Model, BaseMixin, SerializerMixin):
    """
    Describes a production the studio works on.
    """
    name = db.Column(db.String(80), nullable=False, index=True)
    task_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("task.id"),
        index=True,
        nullable=False
    )
    software_version_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("software_version.id"),
        index=True,
        nullable=False
    )
    # prefix = db.Column(db.String(20), unique=True, index=True, default="")
    suffix = db.Column(db.String(20), index=True, default="")
    version_logs = db.relationship("VersionLog", backref="file", lazy="select")

    __table_args__ = (
        db.UniqueConstraint(
            "name",
            "suffix",
            "task_id",
            name="file_uc",
        ),
    )