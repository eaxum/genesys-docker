from genesys.app.models.base import BaseMixin
from genesys.app import db
from genesys.app.models.serializer import SerializerMixin
from sqlalchemy_utils import UUIDType

class Task(db.Model, BaseMixin, SerializerMixin):
    """
    Describes a production the studio works on.
    """
    name = db.Column(db.String(80), nullable=False, unique=True, index=True)
    secondary_id = secondary_id = db.Column(db.String(80), nullable=False, unique=True, index=True)
    entity_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("entity.id"),
        index=True,
        nullable=False
    )
    project_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("project.id"),
        index=True,
    )

    files = db.relationship(
        "File",
        backref=db.backref("task", lazy="select"),
        lazy="select",
    )

    # add constraint to ensure that the task is unique per entity
    __table_args__ = (
        db.UniqueConstraint(
            'name',
            'project_id',
            'entity_id',
            name='task_uc'
        ),
    )