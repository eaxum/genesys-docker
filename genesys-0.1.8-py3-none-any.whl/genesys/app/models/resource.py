from genesys.app.models.base import BaseMixin
from genesys.app import db
from genesys.app.models.serializer import SerializerMixin
from sqlalchemy_utils import UUIDType

file_resource = db.Table(
    "file_resource",
    db.Column(
        "file_id", UUIDType(binary=False), db.ForeignKey("file.id"), index=True
    ),
    db.Column(
        "resource_id", UUIDType(binary=False), db.ForeignKey("resource.id"), index=True
    ),
)

class Resource(db.Model, BaseMixin, SerializerMixin):
    """
    Describes a production the studio works on.
    """
    name = db.Column(db.String(80), nullable=False, unique=True, index=True)
    resource_type_id = db.Column(
        UUIDType(binary=False), db.ForeignKey("resource_type.id"), index=True
    )

