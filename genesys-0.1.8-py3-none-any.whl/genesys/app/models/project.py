from genesys.app.models.base import BaseMixin
from genesys.app import db
from genesys.app.models.serializer import SerializerMixin
from sqlalchemy_utils import UUIDType

class Project(db.Model, BaseMixin, SerializerMixin):
    """
    Describes a production the studio works on.
    """
    secondary_id = db.Column(db.String(80), nullable=False, unique=True, index=True)
    name = db.Column(db.String(80), nullable=False, unique=True, index=True)
    project_status_id = db.Column(
        UUIDType(binary=False), db.ForeignKey("project_status.id"), index=True
    )

