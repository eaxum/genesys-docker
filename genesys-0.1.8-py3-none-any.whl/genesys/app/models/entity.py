from sqlalchemy_utils import UUIDType

from genesys.app import db
from genesys.app.models.serializer import SerializerMixin
from genesys.app.models.base import BaseMixin
from genesys.app.utils import fields


class EntityLink(db.Model, BaseMixin, SerializerMixin):
    __tablename__ = "entity_link"
    entity_in_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("entity.id"),
        primary_key=True,
        index=True,
    )
    entity_out_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("entity.id"),
        primary_key=True,
        index=True,
    )
    nb_occurences = db.Column(db.Integer, default=1)

    __table_args__ = (
        db.UniqueConstraint(
            "entity_in_id",
            "entity_out_id",
            name="entity_link_uc",
        ),
    )

class Entity(db.Model, BaseMixin, SerializerMixin):
    """
    Base model to represent assets, shots, sequences, episodes and scenes.
    They have different meaning but they share the same behaviour toward
    tasks and files.
    """

    name = db.Column(db.String(160), nullable=False, index=True)
    secondary_id = secondary_id = db.Column(db.String(80), nullable=False, unique=True, index=True)
    nb_entities_out = db.Column(db.Integer, default=0)

    parent_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("entity.id"),
        nullable=True,
        index=True,
    )
    # remote_side id is coming through BaseMixin
    parent = db.relationship(
        "Entity",
        remote_side="Entity.id",
        backref=db.backref("children", lazy="select"),
    )

    project_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("project.id"),
        nullable=False,
        index=True,
    )
    entity_type_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("entity_type.id"),
        nullable=False,
        index=True,
    )

    entities_out = db.relationship(
        "Entity",
        secondary="entity_link",
        # id is coming from BaseMixin do primary join with that in mind
        primaryjoin="Entity.id==EntityLink.entity_in_id",
        secondaryjoin="Entity.id==EntityLink.entity_out_id",
        backref=db.backref("entities_in", lazy="select"),
        lazy="select",

    )


    __table_args__ = (
        db.UniqueConstraint(
            "name",
            "project_id",
            "entity_type_id",
            name="entity_uc",
        ),
    )

    def set_entities_out(self, entity_ids):
        self.entities_out = []
        for entity_id in entity_ids:
            entity = Entity.get(entity_id)
            if entity is not None:
                self.entities_out.append(entity)
        self.save()