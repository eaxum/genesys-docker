from genesys.app.models.base import BaseMixin
from genesys.app import db
from genesys.app.models.serializer import SerializerMixin
from sqlalchemy_utils import UUIDType

snapshot_file = db.Table(
    "snapshot_file",
    db.Column(
        "snapshot_id", UUIDType(binary=False), db.ForeignKey("snapshot.id"), index=True
    ),
    db.Column(
        "file_id", UUIDType(binary=False), db.ForeignKey("file.id"), index=True
    ),
)

snapshot_resource = db.Table(
    "snapshot_resource",
    db.Column(
        "snapshot_id", UUIDType(binary=False), db.ForeignKey("snapshot.id"), index=True
    ),
    db.Column(
        "resource_id", UUIDType(binary=False), db.ForeignKey("resource.id"), index=True
    ),
)

class Snapshot(db.Model, BaseMixin, SerializerMixin):
    """
    Describes a production the studio works on.
    """
    name = db.Column(db.String(80), nullable=False, unique=True, index=True)
    entity_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("entity.id"),
        index=True
    )


