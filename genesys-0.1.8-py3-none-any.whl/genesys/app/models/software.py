from genesys.app.models.base import BaseMixin
from genesys.app import db
from genesys.app.models.serializer import SerializerMixin
from sqlalchemy_utils import UUIDType

class Software(db.Model, BaseMixin, SerializerMixin):
    """
    Describes a production the studio works on.
    """
    name = db.Column(db.String(80), nullable=False, unique=True, index=True)
    extension = db.Column(db.String(20), nullable=False)
    versions = db.relationship("SoftwareVersion", backref="software", lazy="select")

class SoftwareVersion(db.Model, BaseMixin, SerializerMixin):
    """
    Describes a production the studio works on.
    """
    software_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("software.id"),
        index=True,
        nullable=False
    )
    version = db.Column(db.String(20), nullable=False)
    tools = db.relationship("Tool", backref="software", lazy="select")
  
    __table_args__ = (
        db.UniqueConstraint(
            "version",
            "software_id",
            name="software_version_uc",
        ),
    )

