from genesys.app.models.base import BaseMixin
from genesys.app import db
from genesys.app.models.serializer import SerializerMixin
from sqlalchemy_utils import UUIDType, ChoiceType

project_tool = db.Table(
    "project_tool",
    db.Column(
        "project_id", UUIDType(binary=False), db.ForeignKey("project.id"), index=True
    ),
    db.Column(
        "tool_id", UUIDType(binary=False), db.ForeignKey("tool.id"), index=True
    ),
)

file_tool = db.Table(
    "file_tool",
    db.Column(
        "file_id", UUIDType(binary=False), db.ForeignKey("file.id"), index=True
    ),
    db.Column(
        "tool_id", UUIDType(binary=False), db.ForeignKey("tool.id"), index=True
    ),
)

class Tool(db.Model, BaseMixin, SerializerMixin):
    """
    Describes a production the studio works on.
    """
    name = db.Column(db.String(80), nullable=False, unique=True, index=True)
    tool_type_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("tool_type.id"),
        nullable=False,
        index=True,
    )
    software_version_id = db.Column(
        UUIDType(binary=False),
        db.ForeignKey("software_version.id"),
        index=True, 
        nullable=True
    )
    version = db.Column(db.String(20), nullable=False)

