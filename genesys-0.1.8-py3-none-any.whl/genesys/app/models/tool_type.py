from genesys.app import db
from genesys.app.models.serializer import SerializerMixin
from genesys.app.models.base import BaseMixin

class ToolType(db.Model, BaseMixin, SerializerMixin):
    """
    Type of tools. It can describe either a plugin or external tool required
    by a project or a specific software.
    """

    name = db.Column(db.String(30), unique=True, nullable=False, index=True)