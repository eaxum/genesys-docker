import os
import tempfile
from genesys.app.utils import dbhelpers
SVN_PARENT_PATH = os.getenv("SVN_PARENT_PATH", '/opt/svn/repositories')
SVN_PARENT_URL = os.getenv("SVN_PARENT_URL", "file:////opt/svn/repositories")
LOGIN_NAME = os.getenv("LOGIN_NAME", "email")
TEMPLATE_FILES_DIR =os.path.join(os.path.dirname(__file__), 'template_files')

ENABLE_JOB_QUEUE = os.getenv("ENABLE_JOB_QUEUE", "False").lower() == "true"
ENABLE_JOB_QUEUE_REMOTE = (
    os.getenv("ENABLE_JOB_QUEUE_REMOTE", "False").lower() == "true"
)

DATABASE = {
    "drivername": os.getenv("DB_DRIVER", "postgresql"),
    "host": os.getenv("DB_HOST", "localhost"),
    "port": os.getenv("DB_PORT", "5432"),
    # "port": os.getenv("DB_PORT", "8007"),
    "username": os.getenv("DB_USERNAME", "postgres"),
    "password": os.getenv("password", "Un53cur3Pa55w0rd"),
    # "password": os.getenv("DB_PASSWORD", "mysecretpassword"),
    "database": os.getenv("DB_DATABASE", "genesysdb"),
}

SQLALCHEMY_DATABASE_URI = dbhelpers.get_db_uri()
SQLALCHEMY_TRACK_MODIFICATIONS = False
SQLALCHEMY_ENGINE_OPTIONS = {
    "pool_size": int(os.getenv("DB_POOL_SIZE", 30)),
    "max_overflow": int(os.getenv("DB_MAX_OVERFLOW", 60)),
}

KEY_VALUE_STORE = {
    "host": os.getenv("KV_HOST", "localhost"),
    "port": os.getenv("KV_PORT", "6379"),
}
KV_JOB_DB_INDEX = 7
MEMOIZE_DB_INDEX = 1

FS_BACKEND = os.getenv("FS_BACKEND", "local")

TEMPLATE_FOLDER = os.getenv(
    "TEMPLATE_FOLDER",
    os.getenv("TEMPLATE_FOLDER", os.path.join(os.getcwd(), "templates")),
)

TMP_DIR = os.getenv("TMP_DIR", os.path.join(tempfile.gettempdir(), "genesys"))

FS_BACKEND = os.getenv("FS_BACKEND", "local")
FS_ROOT = TEMPLATE_FOLDER
FS_BUCKET_PREFIX = os.getenv("FS_BUCKET_PREFIX", "")