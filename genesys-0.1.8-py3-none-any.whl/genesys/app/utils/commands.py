# coding: utf-8
from genesys.app.services import (
    entities_service,
    backup_service,
    projects_service,
    tools_service,
    softwares_service
)

from genesys.app import app
import os

def init_data():
    """
    Put the minimum required data into the database to start with it.
    """
    with app.app_context():
        projects_service.get_open_status()
        projects_service.get_closed_status()
        projects_service.get_achieved_status()
        print("Project status initialized.")

        entities_service.get_or_create_entity_type("character")
        entities_service.get_or_create_entity_type("prop")
        entities_service.get_or_create_entity_type("environment")
        entities_service.get_or_create_entity_type("fx")
        entities_service.get_or_create_entity_type("set")
        entities_service.get_or_create_entity_type("shot")
        entities_service.get_or_create_entity_type("sequence")
        entities_service.get_or_create_entity_type("episode")
        entities_service.get_or_create_entity_type("edit")
        print("Entity types initialized.")

        tools_service.get_or_create_tool_type("software")
        tools_service.get_or_create_tool_type("hardware")
        tools_service.get_or_create_tool_type("service")
        tools_service.get_or_create_tool_type("plugin")
        print("Tool types initialized.")

        blender = softwares_service.get_or_create_software("blender", "blend")
        affinity_designer = softwares_service.get_or_create_software("affinity Designer", "afdesign")
        fL_studio = softwares_service.get_or_create_software("fL studio", "flp")
        clip_studio_paint = softwares_service.get_or_create_software("clip studio paint", "clip")
        sketch_book = softwares_service.get_or_create_software("sketch book", "tif")
        print("Softwares initialized.")

        default_templates_folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), "template_files")
        blender_default_file = os.path.join(default_templates_folder, "blender.blend")
        with open(blender_default_file, "rb") as f:
            blender_2_8 = softwares_service.get_or_create_software_version(blender['id'], "2.8", f.read())

        print("Software versions initialized.")


def dump_database():
    """
    Dump the database into a file.
    """
    filename = backup_service.generate_db_backup(
        app.config["DATABASE"]["host"],
        app.config["DATABASE"]["port"],
        app.config["DATABASE"]["username"],
        app.config["DATABASE"]["password"],
        app.config["DATABASE"]["database"],
    )
    backup_service.store_db_backup(filename)