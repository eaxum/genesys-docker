from genesys.app.blueprints.crud import blueprint as crud_blueprint
from genesys.app.blueprints.file import blueprint as file_blueprint
# from genesys.app.blueprints.index import blueprint as index_blueprint


def configure(app):
    """
    Turn Flask app into a REST API. It configures routes, auth and events
    system.
    """
    app.url_map.strict_slashes = False
    configure_api_routes(app)
    return app


def configure_api_routes(app):
    """
    Register blueprints (modules). Each blueprint describe routes and
    associated resources (controllers).
    """
    app.register_blueprint(crud_blueprint)
    app.register_blueprint(file_blueprint)
    return app