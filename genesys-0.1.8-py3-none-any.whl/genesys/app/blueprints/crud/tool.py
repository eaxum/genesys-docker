from flask import current_app

from sqlalchemy.exc import StatementError

from genesys.app.models.tool import Tool
from genesys.app.services import (
    tools_service,
)

from werkzeug.exceptions import NotFound

from genesys.app.blueprints.crud.base import BaseModelResource, BaseModelsResource


class ToolsResource(BaseModelsResource):
    def __init__(self):
        BaseModelsResource.__init__(self, Tool)


class ToolResource(BaseModelResource):
    def __init__(self):
        BaseModelResource.__init__(self, Tool)
        self.protected_fields += [
            "project_id",
            "tool_type_id",
        ]

    def serialize_instance(self, tool):
        tool = tool.serialize(relations=True)
        # tool["type"] = shots_service.get_base_tool_type_name(tool)
        return tool

    def put(self, instance_id):
        """
        Update a model with data given in the request body. JSON format is
        expected. Model performs the validation automatically when fields are
        modified.
        """
        try:
            data = self.get_arguments()
            tool = self.get_model_or_404(instance_id)

            data = self.update_data(data, instance_id)

            tool.update(data)
            tool_dict = self.serialize_instance(tool)
            tools_service.clear_tool_cache(tool_dict["id"])
            return tool_dict, 200

        except StatementError as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"error": True, "message": str(exception)}, 400
        except TypeError as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"error": True, "message": str(exception)}, 400
        except NotFound as exception:
            return {"error": True, "message": str(exception)}, 404
        except Exception as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"error": True, "message": str(exception)}, 400
