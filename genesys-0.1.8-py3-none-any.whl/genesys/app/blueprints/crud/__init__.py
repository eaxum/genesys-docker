from flask import Blueprint

from genesys.app.utils.api import configure_api_from_blueprint

from genesys.app.blueprints.crud.project import (
    ProjectResource,
    ProjectsResource,
)

from genesys.app.blueprints.crud.entity_type import (
    EntityTypeResource,
    EntityTypesResource,
)

from genesys.app.blueprints.crud.entity import (
    EntityResource,
    EntitiesResource,
)

from genesys.app.blueprints.crud.task import (
    TaskResource,
    TasksResource,
)

from genesys.app.blueprints.crud.tool_type import (
    ToolTypeResource,
    ToolTypesResource,
)

from genesys.app.blueprints.crud.tool import (
    ToolResource,
    ToolsResource,
)

from genesys.app.blueprints.crud.software import (
    SoftwareResource,
    SoftwaresResource,
    SoftwareVersionResource,
    SoftwareVersionsResource,
)

from genesys.app.blueprints.crud.file import (
    FileResource,
    FilesResource,
)

from genesys.app.blueprints.crud.entity_link import (
    EntityLinkResource,
    EntityLinksResource,
)

routes = [
    ("/data/projects", ProjectsResource),
    ("/data/projects/<instance_id>", ProjectResource),

    ("/data/entity_types", EntityTypesResource),
    ("/data/entity_types/<instance_id>", EntityTypeResource),

    ("/data/entities", EntitiesResource),
    ("/data/entities/<instance_id>", EntityResource),

    ("/data/tasks", TasksResource),
    ("/data/tasks/<instance_id>", TaskResource),

    ("/data/tool_types", ToolTypesResource),
    ("/data/tool_types/<instance_id>", ToolTypeResource),

    ("/data/tools", ToolsResource),
    ("/data/tools/<instance_id>", ToolResource),

    ("/data/softwares", SoftwaresResource),
    ("/data/softwares/<instance_id>", SoftwareResource),
    ("/data/softwares/<instance_id>/versions", SoftwareVersionsResource),
    ("/data/softwares/<instance_id>/versions/<version_id>", SoftwareVersionResource),

    ("/data/files", FilesResource),
    ("/data/files/<instance_id>", FileResource),

    ("/data/entity_links", EntityLinksResource),
    ("/data/entity_links/<instance_id>", EntityLinkResource),
]

blueprint = Blueprint("/data", "data")
api = configure_api_from_blueprint(blueprint, routes)
