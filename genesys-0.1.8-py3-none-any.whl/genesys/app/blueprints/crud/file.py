from flask import current_app, request

from sqlalchemy.exc import StatementError

from genesys.app.models.file import File
from genesys.app.services import (
    files_service,
    softwares_service,
    queue_store,
)

from werkzeug.exceptions import NotFound

from genesys.app.blueprints.crud.base import BaseModelResource, BaseModelsResource
from genesys.app.services.exception import (
    ArgumentsException,
    WrongParameterException,
)
from sqlalchemy.exc import IntegrityError, StatementError
from genesys.app import config


class FilesResource(BaseModelsResource):
    def __init__(self):
        BaseModelsResource.__init__(self, File)

    def post_creation(self, file):
        file_dict = file.serialize()
        files_service.clear_file_cache(file_dict["id"])

        if config.ENABLE_JOB_QUEUE:
            queue_store.job_queue.enqueue(
                files_service.add_file_to_repo,
                args=(file,),
                job_timeout=10,
            )
        else:
            # run files_service.add_file_to_repo in another thread
            import threading
            thread = threading.Thread(
                target=files_service.add_file_to_repo, args=(file,)
            )
            thread.start()
        
        return file_dict

    def post(self):
        try:
            data = request.json
            if data is None:
                raise ArgumentsException(
                    "Data are empty. Please verify that you sent JSON data and"
                    " that you set the right headers."
                )
            software = data.get("software")
            version = data.get("software_version")

            data.pop("software", None)
            data.pop("software_version", None)

            if software is None:
                raise ArgumentsException("Software is not specified.")
            software_version = softwares_service.get_software_version_by_name(software, version)

            data["software_version_id"] = software_version["id"]

            instance = self.model.create(**data)
            instance_dict = self.post_creation(instance)
            return instance_dict, 201

        except TypeError as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"message": str(exception)}, 400

        except IntegrityError as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"message": str(exception)}, 400

        except StatementError as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"message": str(exception)}, 400

        except ArgumentsException as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"message": str(exception)}, 400


class FileResource(BaseModelResource):
    def __init__(self):
        BaseModelResource.__init__(self, File)
        self.protected_fields += [
            "project_id",
            "files_in",
            "files_out",
            "file_type_id",
        ]

    def serialize_instance(self, file):
        file = file.serialize(relations=True)
        # file["type"] = shots_service.get_base_file_type_name(file)
        return file

    def put(self, instance_id):
        """
        Update a model with data given in the request body. JSON format is
        expected. Model performs the validation automatically when fields are
        modified.
        """
        try:
            data = self.get_arguments()
            file = self.get_model_or_404(instance_id)

            data = self.update_data(data, instance_id)

            file.update(data)
            file_dict = self.serialize_instance(file)
            files_service.clear_file_cache(file_dict["id"])
            return file_dict, 200

        except StatementError as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"error": True, "message": str(exception)}, 400
        except TypeError as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"error": True, "message": str(exception)}, 400
        except NotFound as exception:
            return {"error": True, "message": str(exception)}, 404
        except Exception as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"error": True, "message": str(exception)}, 400
