from genesys.app.mixin import ArgsMixin
from genesys.app.models.project import Project
from genesys.app.models.project_status import ProjectStatus
from genesys.app.services import (
    deletion_service,
    projects_service,
    queue_store,
    files_service,
)
from genesys.app.blueprints.crud.base import BaseModelResource, BaseModelsResource
from genesys.app import config
from flask import request


class ProjectsResource(BaseModelsResource):
    def __init__(self):
        BaseModelsResource.__init__(self, Project)

    def update_data(self, data):
        open_status = projects_service.get_or_create_open_status()
        if "project_status_id" not in data:
            data["project_status_id"] = open_status["id"]
        return data

    def post_creation(self, project):
        project_dict = project.serialize()
        projects_service.clear_project_cache("")

        project_name = files_service.format_file_name(project.name)
        if config.ENABLE_JOB_QUEUE:
            queue_store.job_queue.enqueue(
                projects_service.create_project_repo,
                args=(project_name,),
                job_timeout=10,
            )
        else:
            projects_service.create_project_repo(project_name)
        
        return project_dict

    def post_update(self, instance_dict):
        old_project_name = files_service.format_file_name(instance_dict['old_project_name'])
        new_project_name = files_service.format_file_name(instance_dict['new_project_name'])
        if config.ENABLE_JOB_QUEUE:
            queue_store.job_queue.enqueue(
                projects_service.rename_project,
                args=(old_project_name, new_project_name),
                job_timeout=10,
            )
        else:
            projects_service.rename_project(old_project_name, new_project_name)

        return instance_dict


    def put(self):
        data = request.get_json()
        protected_fields = ["id", "secondary_id", "created_at", "updated_at"]
        secondary_id = data.get("secondary_id")
        if not secondary_id:
            return {"error": True, "message": "Missing secondary_id"}, 400
        project = Project.query.filter_by(secondary_id=secondary_id).first()

        project_name = data.get("name")
        if not project_name:
            return {"error": True, "message": "Missing project name"}, 400
        project_name = project_name.lower().strip()
        is_name_changed = project_name != project.name.lower().strip()
        if is_name_changed:
            updated_name = project_name
            old_name = project.name

        if not project:
            return {"error": True, "message": "Project not found"}, 404
        project_data = {k: v for k, v in data.items() if k not in protected_fields}
        project.update(project_data)
        instance_dict = project.serialize()
        projects_service.clear_project_cache(instance_dict["id"])
        instance_dict['old_project_name'] = old_name
        instance_dict['new_project_name'] = updated_name
        self.post_update(instance_dict)
        return instance_dict, 200
        

class ProjectResource(BaseModelResource, ArgsMixin):
    def __init__(self):
        BaseModelResource.__init__(self, Project)

    def pre_update(self, project_dict, data):
        return data

    def post_update(self, project_dict):
        projects_service.clear_project_cache(project_dict["id"])
        return project_dict

    def clean_get_result(self, data):
        project_status = ProjectStatus.get(data["project_status_id"])
        data["project_status_name"] = project_status.name
        return data

    def post_delete(self, project_dict):
        projects_service.clear_project_cache(project_dict["id"])
        project_name = project_dict['name']
        project_name = files_service.format_file_name(project_name)
        if config.ENABLE_JOB_QUEUE:
            queue_store.job_queue.enqueue(
                projects_service.archive_project,
                args=(project_name,),
                job_timeout=10,
            )
        else:
            projects_service.archive_project(project_name)

        return project_dict

    def delete(self, instance_id):
        force = self.get_force()

        project = self.get_model_or_404(instance_id)
        project_dict = project.serialize()
        if projects_service.is_open(project_dict):
            return {
                "error": True,
                "message": "Only closed projects can be deleted",
            }, 400
        else:
            if force:
                deletion_service.remove_project(instance_id)
            else:
                project.delete()
            self.post_delete(project_dict)
            return "", 204
