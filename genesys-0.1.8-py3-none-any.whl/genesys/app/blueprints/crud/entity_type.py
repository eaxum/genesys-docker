from genesys.app.blueprints.crud.base import BaseModelResource, BaseModelsResource

from genesys.app.models.entity_type import EntityType
from genesys.app.services import entities_service


class EntityTypesResource(BaseModelsResource):
    def __init__(self):
        BaseModelsResource.__init__(self, EntityType)

    # def post_creation(self, instance):
        
    #     return instance.serialize(relations=True)


class EntityTypeResource(BaseModelResource):
    def __init__(self):
        BaseModelResource.__init__(self, EntityType)

    def post_update(self, instance_dict):
        entities_service.clear_entity_type_cache(instance_dict["id"])
        return instance_dict

    def post_delete(self, instance_dict):
        entities_service.clear_entity_type_cache(instance_dict["id"])
        return instance_dict