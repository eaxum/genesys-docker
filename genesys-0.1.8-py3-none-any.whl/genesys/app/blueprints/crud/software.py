from flask import request, current_app

from sqlalchemy.exc import StatementError

from genesys.app.models.software import Software, SoftwareVersion

from genesys.app.services import (
    softwares_service,
)

from werkzeug.exceptions import NotFound

from genesys.app.blueprints.crud.base import BaseModelResource, BaseModelsResource
from genesys.app.stores import file_store
from genesys.app.services import (
    softwares_service,
)

import os

class SoftwaresResource(BaseModelsResource):
    def __init__(self):
        BaseModelsResource.__init__(self, Software)

    # def all_entries(self, query=None, relations=False):
    #     softwares = BaseModelsResource.all_entries(
    #         self, query=query, relations=relations
    #     )
    #     for software in softwares:
    #         software["type"] = shots_service.get_base_software_type_name(software)
    #     return softwares


class SoftwareResource(BaseModelResource):
    def __init__(self):
        BaseModelResource.__init__(self, Software)


class SoftwareVersionsResource(BaseModelsResource):
    def __init__(self):
        BaseModelsResource.__init__(self, SoftwareVersion)

    def get(self, instance_id):
        try:
            software = Software.query.get(instance_id)
        except StatementError:
            raise NotFound()

        software_versions = SoftwareVersion.get_all_by(software_id=instance_id)
        software_versions = [software_version.serialize() for software_version in software_versions]
        return software_versions, 200
    
    def post(self, instance_id):
        try:
            software = Software.query.get(instance_id)
        except StatementError:
            raise NotFound()

        if not software:
            raise NotFound()
        
        data = {}
        uploaded_file = request.files['file']
        print('uploaded_file', uploaded_file)
        version = request.form['version']

        # extension = fs.get_file_extension(uploaded_file.filename)
        extension = software.extension

        data['software_id'] = instance_id
        data['version'] = version
        instance = self.model(**data)
        instance.save()
        self.save_template_file(str(instance.id), uploaded_file, extension)

        return softwares_service.get_software_with_relations(str(instance_id)), 201
    
    def save_template_file(self, software_version_id, uploaded_file, extension):
        """
        Get uploaded file then save it in the file storage.
        """
        tmp_folder = current_app.config["TMP_DIR"]
        file_name = software_version_id + '.' + extension
        file_path = os.path.join(tmp_folder, file_name)
        uploaded_file.save(file_path)
        file_store.add_file("templates", software_version_id, file_path)
        os.remove(file_path)
        return file_path

class SoftwareVersionResource(BaseModelResource):
    def __init__(self):
        BaseModelResource.__init__(self, Software)