from flask import request, current_app

from sqlalchemy.exc import IntegrityError
from genesys.app.mixin import ArgsMixin
from genesys.app.models.task import Task

from genesys.app.services import (
    tasks_service,
    deletion_service,
    entities_service,
)

from genesys.app.blueprints.crud.base import BaseModelsResource, BaseModelResource


class TasksResource(BaseModelsResource):
    def __init__(self):
        BaseModelsResource.__init__(self, Task)

    def post(self):
        """
        Create a task with data given in the request body. JSON format is
        expected. The model performs the validation automatically when
        instantiated.
        """
        try:
            data = request.json

            entity = entities_service.get_entity(data["entity_id"])

            data['project_id'] = entity['project_id']

            instance = self.model(**data)
            instance.save()

            return tasks_service.get_task_with_relations(str(instance.id)), 201

        except TypeError as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"message": str(exception)}, 400

        except IntegrityError as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"message": "Task already exists."}, 400


class TaskResource(BaseModelResource, ArgsMixin):
    def __init__(self):
        BaseModelResource.__init__(self, Task)

    # def post_update(self, instance_dict):
    #     tasks_service.clear_task_cache(instance_dict["id"])
    #     return instance_dict

    # def pre_update(self, instance_dict, data):
    #     if "assignees" in data:
    #         data["assignees"] = [
    #             persons_service.get_person_raw(assignee)
    #             for assignee in data["assignees"]
    #         ]
    #     return data


    def delete(self, instance_id):
        """
        Delete a model corresponding at given ID and return it as a JSON
        object.
        """
        force = self.get_force()

        instance = self.get_model_or_404(instance_id)

        try:
            instance_dict = instance.serialize()
            deletion_service.remove_task(instance_id, force=force)
            tasks_service.clear_task_cache(instance_id)
            self.post_delete(instance_dict)

        except IntegrityError as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"message": str(exception)}, 400

        return "", 204
