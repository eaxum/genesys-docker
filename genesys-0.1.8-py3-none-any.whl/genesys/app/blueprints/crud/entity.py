from flask import current_app

from sqlalchemy.exc import StatementError

from genesys.app.models.entity import Entity
from genesys.app.services import (
    entities_service,
    queue_store
)

from werkzeug.exceptions import NotFound

from genesys.app.blueprints.crud.base import BaseModelResource, BaseModelsResource
from genesys.app import config


class EntitiesResource(BaseModelsResource):
    def __init__(self):
        BaseModelsResource.__init__(self, Entity)

    def post_creation(self, entity):
        entity_dict = entity.serialize()
        entities_service.clear_entity_cache(entity.id)

        if config.ENABLE_JOB_QUEUE:
            queue_store.job_queue.enqueue(
                entities_service.add_entity_to_repo,
                args=(entity,),
                job_timeout=10,
            )
        else:
            entities_service.add_entity_to_repo(entity)
        
        return entity_dict


class EntityResource(BaseModelResource):
    def __init__(self):
        BaseModelResource.__init__(self, Entity)
        self.protected_fields += [
            "project_id",
            "entities_in",
            "entities_out",
            "entity_type_id",
        ]

    def serialize_instance(self, entity):
        entity = entity.serialize(relations=True)
        # entity["type"] = shots_service.get_base_entity_type_name(entity)
        return entity

    def put(self, instance_id):
        """
        Update a model with data given in the request body. JSON format is
        expected. Model performs the validation automatically when fields are
        modified.
        """
        try:
            data = self.get_arguments()
            entity = self.get_model_or_404(instance_id)

            data = self.update_data(data, instance_id)

            entity.update(data)
            entity_dict = self.serialize_instance(entity)
            entities_service.clear_entity_cache(entity_dict["id"])
            return entity_dict, 200

        except StatementError as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"error": True, "message": str(exception)}, 400
        except TypeError as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"error": True, "message": str(exception)}, 400
        except NotFound as exception:
            return {"error": True, "message": str(exception)}, 404
        except Exception as exception:
            current_app.logger.error(str(exception), exc_info=1)
            return {"error": True, "message": str(exception)}, 400
