from genesys.app.blueprints.crud.base import BaseModelResource, BaseModelsResource

from genesys.app.models.tool_type import ToolType
from genesys.app.services import tools_service


class ToolTypesResource(BaseModelsResource):
    def __init__(self):
        BaseModelsResource.__init__(self, ToolType)

    # def post_creation(self, instance):
        
    #     return instance.serialize(relations=True)


class ToolTypeResource(BaseModelResource):
    def __init__(self):
        BaseModelResource.__init__(self, ToolType)

    def post_update(self, instance_dict):
        tools_service.clear_tool_type_cache(instance_dict["id"])
        return instance_dict

    def post_delete(self, instance_dict):
        tools_service.clear_tool_type_cache(instance_dict["id"])
        return instance_dict