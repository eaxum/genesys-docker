from flask import Blueprint

from genesys.app.utils.api import configure_api_from_blueprint

from genesys.app.blueprints.file.resources import (
    File_Access_Control
)

routes = [
    ("/data/acl", File_Access_Control),
]

blueprint = Blueprint("acl", "acl")
api = configure_api_from_blueprint(blueprint, routes)
