from flask import request

from genesys.app.services import (
    files_service,
    queue_store,
)

from genesys.app import config
from flask_restful import Resource

class File_Access_Control(Resource):
    def put(self):
        data = request.get_json()
        task_id = data.get("task_id")
        user = data.get("user")
        permission = data.get("permission")
        dependent_tasks = data.get("dependent_tasks")
        if config.ENABLE_JOB_QUEUE:
            queue_store.job_queue.enqueue(
                files_service.set_task_files_permission,
                args=(task_id, user, permission, dependent_tasks),
                job_timeout=10,
            )
        else:
            files_service.set_task_files_permission(task_id, user, permission, dependent_tasks)
        
        return data, 200