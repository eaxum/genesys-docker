from flask import Flask
import flask_fs
from . import config
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from genesys.app.utils import cache

app = Flask('genesys')
app.config.from_object(config)

db = SQLAlchemy(app)
migrate = Migrate(app, db)
cache.cache.init_app(app)
flask_fs.init_app(app)

from genesys.app.blueprints.index.routes import index
# from genesys.app.blueprints.project.routes import project
# from genesys.app.blueprints.task.routes import task
# from genesys.app.blueprints.asset.routes import asset
from genesys.app.blueprints.refresh.routes import refresh


app.register_blueprint(index)
# app.register_blueprint(project)
# app.register_blueprint(task)
# app.register_blueprint(asset)
app.register_blueprint(refresh)
app.config.from_object(config)

def load_api():
    from genesys.app import api
    api.configure(app)
load_api()