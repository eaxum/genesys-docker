from sqlalchemy.exc import StatementError, IntegrityError

from genesys.app.models.task import Task

from genesys.app.utils import cache

from genesys.app.services.exception import (
    TaskNotFoundException,
)

from genesys.app.services import (
    projects_service,
    entities_service,
)


def get_task_raw(task_id):
    """
    Get task matching given id as an active record.
    """
    try:
        task = Task.get(task_id)
    except StatementError:
        raise TaskNotFoundException

    if task is None:
        raise TaskNotFoundException

    return task


@cache.memoize_function(120)
def get_task(task_id, relations=False):
    """
    Get task matching given id as a dictionary.
    """
    return get_task_raw(task_id).serialize(relations=relations)


@cache.memoize_function(120)
def get_task_with_relations(task_id):
    """
    Get task matching given id as a dictionary.
    """
    return get_task_raw(task_id).serialize(relations=True)


def get_tasks_for_entity(entity_id, relations=False):
    """
    Get all tasks for given entity.
    """
    entity = entities_service.get_entity_raw(entity_id)
    tasks = entity.tasks
    return [task.serialize(relations=relations) for task in tasks]



def create_tasks(entities):
    """
    Create a new task for given task type and for each entity.
    """

    tasks = []
    for entity in entities:
        existing_task = Task.query.filter_by(entity_id=entity["id"]).scalar()
        if existing_task is None:
            task = Task.create_no_commit(
                name="main",
                start_date=None,
                end_date=None,
                due_date=None,
                real_start_date=None,
                project_id=entity["project_id"],
                entity_id=entity["id"],
                assignees=[],
            )
            tasks.append(task)
    Task.commit()

    task_dicts = []
    for task in tasks:
        task_dict = task.serialize()
        task_dicts.append(task_dict)

    return task_dicts


def create_task(entity, name="main"):
    """
    Create a new task for given task type and entity.
    """
    try:
        task = Task.create(
            name=name,
            project_id=entity["project_id"],
            entity_id=entity["id"],
        )
        task_dict = task.serialize()
        return task_dict
    except IntegrityError:
        pass  # Tasks already exists, no need to create it.
    return None


def clear_task_cache(task_id):
    cache.cache.delete_memoized(get_task, task_id)
    cache.cache.delete_memoized(get_task_with_relations, task_id)


def update_task(task_id, data):
    """
    Update task with given data.
    """
    task = get_task_raw(task_id)

    task.update(data)
    clear_task_cache(task_id)
    return task.serialize()


def get_tasks_for_project(project_id):
    """
    Return all tasks for given project.
    """
    query = Task.query.filter(Task.project_id == project_id).order_by(
        Task.updated_at.desc()
    )
    return [task.serialize() for task in query.all()]


def get_full_task(task_id):
    task = get_task_with_relations(task_id)
    project = projects_service.get_project(task["project_id"])
    entity = entities_service.get_entity(task["entity_id"])
    entity_type = entities_service.get_entity_type(entity["entity_type_id"])
    # assignees = [
    #     persons_service.get_person(assignee_id)
    #     for assignee_id in task["assignees"]
    # ]

    task.update(
        {
            "entity": entity,
            "entity_type": entity_type,
            # "persons": assignees,
            "project": project,
            "type": "Task",
        }
    )
    return task