
from genesys.app.models.entity import Entity, EntityLink
from genesys.app.models.milestone import Milestone
from genesys.app.models.project import Project
from genesys.app.models.task import Task
from genesys.app.stores import file_store
from genesys.app.services import tasks_service

def clear_generic_files(preview_file_id):
    """
    Remove all files related to given preview file, supposing the original file
    was a generic file.
    """
    try:
        file_store.remove_file("previews", preview_file_id)
    except BaseException:
        pass


def remove_project(project_id):
    query = EntityLink.query.join(
        Entity, EntityLink.entity_in_id == Entity.id
    ).filter(Entity.project_id == project_id)
    for link in query:
        link.delete_no_commit()
    EntityLink.commit()

    EntityLink.commit()

    Entity.delete_all_by(project_id=project_id)
    Milestone.delete_all_by(project_id=project_id)

    project = Project.get(project_id)
    project.delete()
    return project_id

def remove_task(task_id, force=False):
    """
    Remove given task. Force deletion if the task has some comments and files
    related. This will lead to the deletion of all of them.
    """
    task = Task.get(task_id)
    if force:
        pass
        # notifications = Notification.query.filter_by(task_id=task_id)
        # for notification in notifications:
        #     notification.delete()

    task.delete()
    tasks_service.clear_task_cache(task_id)
    task_serialized = task.serialize()
    return task_serialized
