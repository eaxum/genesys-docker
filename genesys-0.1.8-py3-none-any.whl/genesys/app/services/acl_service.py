from configparser import ConfigParser, NoSectionError
import os
from genesys.app.config import SVN_PARENT_PATH
from genesys.app.services import files_service

class ACLParser():
    def __init__(self, project_name):
        project_name = files_service.format_file_name(project_name)
        self.acl_path = os.path.join(SVN_PARENT_PATH, project_name, 'conf/authz')
        with open(self.acl_path, 'r') as f:
            acl_data = f.read()
        self.parser = ConfigParser()
        self.parser.read_string(acl_data)
        if not self.parser.sections():
            print("No data in acl file, resetting")
            self.reset()
            self.save()
        self.protected_sections = ["groups", "/"]

    def save(self):
        with open(self.acl_path, 'w') as f:
            self.parser.write(f)

    def reset(self, admin="super-user", super_reader="super-reader"):
        self.parser = ConfigParser()
        self.parser['groups'] = {
                    'admin':admin,
                    'super_reader':super_reader,
                }
        self.parser['/'] = {
                    '*':'r',
                    '@admin':'rw',
                    '@super_reader':'r',
                }

    def reload(self):
        with open(self.acl_path, 'r') as f:
            acl_data = f.read()
        self.parser = ConfigParser()
        self.parser.read_string(acl_data)

    def add_section(self, section):
        try:
            self.parser[section]
        except KeyError:
            self.parser[section] = {}

    def add_option(self, section, option, value):
        try:
            self.parser[section][option] = value
        except KeyError:
            self.parser[section] = {}
            self.parser[section][option] = value

    def add_group(self, group):
        try:
            self.parser['groups'][group]
        except KeyError:
            self.parser['groups'][group] = ""

    def remove_group(self, group):
        try:
            del self.parser['groups'][group]
        except KeyError:
            return  

    def get_groups(self):
        return self.parser['groups']
    
    def get_group_members(self, group):
        try:
            return self.parser['groups'][group].split(",")
        except KeyError:
            return None
        
    def add_user_to_group(self, user, group):
        try:
            # check if user is already in group
            if user in self.parser['groups'][group].split(","):
                return
            if self.parser['groups'][group] == "":
                self.parser['groups'][group] = user
            else:
                self.parser['groups'][group] += f",{user}"
        except KeyError:
            self.parser['groups'][group] = user
    
    def remove_user_from_group(self, user, group):
        try:
            users = self.parser['groups'][group].split(",")
            if user not in users:
                return
            users.remove(user)
            self.parser['groups'][group] = ",".join(users)
        except KeyError:
            return

    def add_path(self, path):
        try:
            self.parser[path]
        except KeyError:
            self.parser[path] = {}
            self.parser[path]["@admin"] = "rw"
            self.parser[path]["*"] = ""

    def remove_path(self, path):
        try:
            del self.parser[path]
        except KeyError:
            return
    
    def give_permission(self, user, path, permission):
        if path in self.protected_sections:
            raise ValueError("Cannot modify protected sections")
        if permission not in ["r", "rw", "d", "none"]:
            raise ValueError("Permission must be r, rw, d, or none")
        self.add_path(path)
        if self.parser[path][user] == 'rw' and permission == 'r':
            return
        elif permission == 'none':
            self.remove_permission(user, path)
        elif permission == 'd' and self.parser[path][user] != 'rw':
            self.remove_permission(user, path)
        else:
            self.parser[path][user] = permission
    
    def remove_permission(self, user, path):
        if path in self.protected_sections:
            raise ValueError("Cannot modify protected sections")
        try:
            del self.parser[path][user]
        except KeyError:
            return

    def give_group_permission(self, group, path, permission):
        if path in self.protected_sections:
            raise ValueError("Cannot modify protected sections")
        if permission not in ["r", "rw"]:
                raise ValueError("Permission must be r or rw")
        group = f"@{group}"
        try:
            self.parser[path][group] = permission
        except KeyError:
            self.parser[path] = {}
            self.parser[path][group] = permission

    def remove_group_permission(self, group, path):
        if path in self.protected_sections:
            raise ValueError("Cannot modify protected sections")
        group = f"@{group}"
        try:
            del self.parser[path][group]
        except KeyError:
            return

    def get_permissions(self, user, path):
        try:
            return self.parser[path][user]
        except KeyError:
            return None
    
    def get_group_permissions(self, group, path):
        try:
            return self.parser[path][f"@{group}"]
        except KeyError:
            return None