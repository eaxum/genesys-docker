from werkzeug.exceptions import NotFound


class ProjectNotFoundException(NotFound):
    pass


class EntityNotFoundException(NotFound):
    pass


class EntityLinkNotFoundException(NotFound):
    pass


class EntityTypeNotFoundException(NotFound):
    pass

class WrongParameterException(Exception):
    pass

class ArgumentsException(Exception):
    pass

class TaskNotFoundException(NotFound):
    pass

class ToolNotFoundException(NotFound):
    pass

class ToolTypeNotFoundException(NotFound):
    pass

class TemplateFileNotFoundException(NotFound):
    pass

class SoftwareNotFoundException(NotFound):
    pass

class SoftwareVersionNotFoundException(NotFound):
    pass

class FileNotFoundException(NotFound):
    pass