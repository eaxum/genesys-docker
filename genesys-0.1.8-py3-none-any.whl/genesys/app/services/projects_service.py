import os
import shutil
from genesys.app.models.project_status import ProjectStatus
from genesys.app.models.project import Project

from genesys.app.services.exception import (
    ProjectNotFoundException,
)

from genesys.app.utils import fields, cache

from sqlalchemy.exc import StatementError

from genesys.app.services import svn_service, files_service, queue_store
from genesys.app.config import SVN_PARENT_PATH, SVN_PARENT_URL


def clear_project_cache(project_id):
    cache.cache.delete_memoized(get_project, project_id)
    cache.cache.delete_memoized(get_project_with_relations, project_id)
    cache.cache.delete_memoized(get_project_by_name)
    cache.cache.delete_memoized(open_projects)


@cache.memoize_function(120)
def open_projects(name=None):
    """
    Return all open projects. Allow to filter projects by name.
    """
    query = (
        Project.query.join(ProjectStatus)
        .filter(ProjectStatus.name.in_(("Active", "open", "Open")))
        .order_by(Project.name)
    )

    if name is not None:
        query = query.filter(Project.name == name)

    return [project.serialize() for project in query.all()]


def open_project_ids():
    """
    Return all open project ids. Allow to filter projects by name.
    """
    return [project["id"] for project in open_projects()]


def get_projects():
    """
    Return all projects. Allow to filter projects by name.
    """
    query = (
        Project.query.join(ProjectStatus)
        .add_columns(ProjectStatus.name)
        .order_by(Project.name)
    )

    result = []
    for entry in query.all():
        (project, project_status_name) = entry
        data = project.serialize()
        data["project_status_name"] = project_status_name
        result.append(data)

    return result


@cache.memoize_function(480)
def get_project_statuses():
    return fields.serialize_models(ProjectStatus.get_all())


def get_or_create_open_status():
    """
    Return open status. If it does not exist, it creates it.
    """
    return get_or_create_status("Open")


@cache.memoize_function(480)
def get_open_status():
    """
    Return open status. If it does not exist, it creates it.
    """
    return get_or_create_status("Open")


@cache.memoize_function(120)
def get_closed_status():
    """
    Return closed status. If it does not exist, it creates it.
    """
    return get_or_create_status("Closed")


@cache.memoize_function(120)
def get_achieved_status():
    """
    Return achieved status. If it does not exist, it creates it.
    """
    return get_or_create_status("Achieved")


def get_or_create_status(name):
    """
    Return given status. If it does not exist, it creates it.
    """
    project_status = ProjectStatus.get_by(name=name)
    if project_status is None:
        project_status = ProjectStatus(name=name)
        project_status.save()
    return project_status.serialize()


def save_project_status(project_statuses):
    """
    Save in database all project status given in parameter.
    """
    result = []
    filtered_satuses = (x for x in project_statuses if x is not None)

    for status in filtered_satuses:
        project_status = get_or_create_status(status)
        result.append(project_status)
    return result


def get_or_create_project(name):
    """
    Get project which match given name. Create it if it does not exist.
    """
    project = Project.get_by(name=name)
    if project is None:
        open_status = get_or_create_open_status()
        project = Project(name=name, project_status_id=open_status["id"])
        project.save()
    return project.serialize()


def get_project_raw(project_id):
    """
    Get project matching given id, as active record. Raises an exception if
    project is not found.
    """
    try:
        project = Project.get(project_id)
    except StatementError:
        raise ProjectNotFoundException()

    if project is None:
        raise ProjectNotFoundException()

    return project


@cache.memoize_function(240)
def get_project(project_id):
    """
    Get project matching given id, as a dict. Raises an exception if project is
    not found.
    """
    return get_project_raw(project_id).serialize()


@cache.memoize_function(240)
def get_project_with_relations(project_id):
    """
    Get project matching given id, as a dict. Raises an exception if project is
    not found.
    """
    return get_project_raw(project_id).serialize(relations=True)


@cache.memoize_function(120)
def get_project_by_name(project_name):
    """
    Get project matching given name. Raises an exception if project is not
    found.
    """
    project = Project.query.filter(Project.name.ilike(project_name)).first()

    if project is None:
        raise ProjectNotFoundException()

    return project.serialize()


def update_project(project_id, data):
    """
    Update project matching given id with data from *data* dict.
    """
    project = get_project_raw(project_id)
    project.update(data)
    clear_project_cache(project_id)
    return project.serialize()


def is_open(project):
    """Return True if project is open."""
    open_status = get_open_status()
    return project["project_status_id"] == open_status["id"]


def is_achieved(project):
    """Return True if project is achieved."""
    achieved_status = get_achieved_status()
    return project["project_status_id"] == achieved_status["id"]

def create_project_repo(project_name):
    project_svn_folder = os.path.join(SVN_PARENT_PATH, project_name)

    svn_service.create_svn_repo(project_svn_folder)
    svn_service.default_acl(project_name)

def rename_project(old_project_name, new_project_name):
    """
    rename project folder and repository and also relocates svn repo
    """
    new_project_svn_folder = os.path.join(SVN_PARENT_PATH, new_project_name)
    old_project_svn_folder = os.path.join(SVN_PARENT_PATH, old_project_name)
    shutil.move(old_project_svn_folder, new_project_svn_folder)

def archive_project(project_name):
    project_svn_folder = os.path.join(SVN_PARENT_PATH, project_name)
    svn_archive_folder = os.path.join(SVN_PARENT_PATH, 'archive')

    if not os.path.exists(svn_archive_folder):
        os.makedirs(svn_archive_folder)

    shutil.make_archive(base_name=os.path.join(svn_archive_folder, project_name), format='zip',
                        root_dir= project_svn_folder)
    shutil.rmtree(project_svn_folder)
