from genesys.app.services import (
    base_service,
    projects_service,
    svn_service,
    files_service
)
from genesys.app.services.acl_service import ACLParser
from genesys.app.utils import cache

from genesys.app.models.entity import Entity, EntityLink
from genesys.app.models.entity_type import EntityType

from genesys.app.services.exception import (
    EntityLinkNotFoundException,
    EntityNotFoundException,
    EntityTypeNotFoundException,
)
from slugify import slugify
from genesys.app.config import (SVN_PARENT_PATH,
                                SVN_PARENT_URL,)

import os
from genesys.app import app


def clear_entity_cache(entity_id):
    cache.cache.delete_memoized(get_entity, entity_id)


def clear_entity_type_cache(entity_type_id):
    cache.cache.delete_memoized(get_entity_type, entity_type_id)
    cache.cache.delete_memoized(get_entity_type_by_name)


@cache.memoize_function(240)
def get_entity_type(entity_type_id):
    """
    Return an entity type matching given id, as a dict. Raises an exception
    if nothing is found.
    """
    return base_service.get_instance(
        EntityType, entity_type_id, EntityTypeNotFoundException
    ).serialize()


def get_or_create_entity_type(name):
    """
    Return entity type maching *name*. If it doesn't exist, it creates it.
    """
    entity_type = EntityType.get_by(name=name)
    if entity_type is None:
        entity_type = EntityType.create(name=name)
    return entity_type.serialize()


@cache.memoize_function(240)
def get_entity_type_by_name(name):
    """
    Return entity type maching *name*. If it doesn't exist, it creates it.
    """
    entity_type = EntityType.get_by(name=name)
    if entity_type is None:
        entity_type = EntityType.create(name=name)
    return entity_type.serialize()


@cache.memoize_function(240)
def get_entity_type_by_name_or_not_found(name):
    """
    Return entity type maching *name*. If it doesn't exist, it creates it.
    """
    entity_type = EntityType.get_by(name=name)
    if entity_type is None:
        raise EntityTypeNotFoundException
    return entity_type.serialize()


def get_entity_raw(entity_id):
    """
    Return an entity type matching given id, as an active record. Raises an
    exception if nothing is found.
    """
    return base_service.get_instance(
        Entity, entity_id, EntityNotFoundException
    )


@cache.memoize_function(120)
def get_entity(entity_id):
    """
    Return an entity type matching given id, as a dict. Raises an exception if
    nothing is found.
    """
    return base_service.get_instance(
        Entity, entity_id, EntityNotFoundException
    ).serialize()


def get_entities_for_project(
    project_id,
    entity_type_id,
    obj_type="Entity",
):
    """
    Retrieve all entities related to given project of which entity is entity
    type.
    """
    query = (
        Entity.query.filter(Entity.entity_type_id == entity_type_id)
        .filter(Entity.project_id == project_id)
        .order_by(Entity.name)
    )
    result = query.all()
    return Entity.serialize_list(result, obj_type=obj_type)


def get_entity_links_for_project(project_id):
    """
    Retrieve entity links for
    """
    query = EntityLink.query.join(
        Entity, EntityLink.entity_in_id == Entity.id
    ).filter(Entity.project_id == project_id)
    result = query.all()
    return Entity.serialize_list(result)


def remove_entity_link(link_id):
    try:
        link = EntityLink.get_by(id=link_id)
        link.delete()
        return link.serialize()
    except BaseException:
        raise EntityLinkNotFoundException


def get_entity_path(entity, path=None):
    """
    Return path of entity matching given id.
    """
    if path is None:
        path = []
    entity_name = slugify(entity.name, separator="_")
    path.append(entity_name)
    if entity.parent_id is None:
        entity_type_id = entity.entity_type_id
        entity_type_name = slugify(get_entity_type(entity_type_id)["name"], separator="_")

        project = projects_service.get_project_raw(entity.project_id)
        project_name = slugify(project.name, separator="_")

        path_list = [project_name, entity_type_name] + path[::-1]
        built_path = "/".join(path_list)
        return built_path
    return get_entity_path(get_entity_raw(entity.parent_id), path=path)

def add_entity_to_repo(entity):
    with app.app_context():
        entity_path = get_entity_path(entity)
    entity_url = os.path.join(SVN_PARENT_URL, entity_path)
    if not svn_service.is_svn_url(entity_url):
        svn_service.svn_make_dirs(entity_url, log_message=f'created {entity.name}')
        svn_acl_entity_path = files_service.get_acl_path(entity_path)
        with app.app_context():
            project = projects_service.get_project_raw(entity.project_id)
        acl_parser = ACLParser(project_name=project.name)
        acl_parser.add_path(svn_acl_entity_path)
        acl_parser.save()
