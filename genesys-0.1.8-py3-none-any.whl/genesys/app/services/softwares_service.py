from genesys.app.services import (
    base_service,
)
from genesys.app.utils import cache

from genesys.app.models.software import Software, SoftwareVersion

from genesys.app.services.exception import (
    SoftwareNotFoundException,
    SoftwareVersionNotFoundException,
)

from genesys.app.stores import file_store

from genesys.app.utils import fs

from genesys.app import config
import os
from flask import current_app
from sqlalchemy.exc import StatementError
from werkzeug.exceptions import NotFound


def clear_software_cache(software_id):
    cache.cache.delete_memoized(get_software, software_id)


def get_software_raw(software_id):
    """
    Return an software type matching given id, as an active record. Raises an
    exception if nothing is found.
    """
    return base_service.get_instance(
        Software, software_id, SoftwareNotFoundException
    )


@cache.memoize_function(120)
def get_software(software_id):
    """
    Return an software type matching given id, as a dict. Raises an exception if
    nothing is found.
    """
    return base_service.get_instance(
        Software, software_id, SoftwareNotFoundException
    ).serialize()

def get_software_with_relations(software_id):
    """
    Return an software type matching given id, as a dict. Raises an exception if
    nothing is found.
    """
    return get_software_raw(software_id).serialize(relations=True)

def get_software_by_name(name):
    """
    Return an software type matching given name, as a dict. Raises an exception if
    nothing is found.
    """
    software = Software.get_by(name=name.lower())
    if software is None:
        raise SoftwareNotFoundException()
    return software.serialize()

def get_software_latest_version(name):
    """
    Return an software type matching given name, as a dict. Raises an exception if
    nothing is found.
    """
    software = Software.get_by(name=name.lower())
    if software is None:
        raise SoftwareNotFoundException()
    versions = SoftwareVersion.get_by(software_id=software.id)
    if versions is None:
        raise SoftwareNotFoundException()
    latest = versions[-1]
    return latest.serialize()

def get_software_version_by_name(software, version):
    """
    Return an software type matching given name, as a dict. Raises an exception if
    nothing is found.
    """
    software = Software.get_by(name=software.lower())
    if software is None:
        raise SoftwareNotFoundException()
    versions = SoftwareVersion.get_all_by(software_id=software.id)
    if versions is None:
        raise SoftwareNotFoundException()
    for v in versions:
        if v.version == version:
            return v.serialize()
    raise SoftwareNotFoundException()

def get_or_create_software(name, extension):
    """
    Return entity type maching *name*. If it doesn't exist, it creates it.
    """
    software = Software.get_by(name=name, extension=extension)
    if software is None:
        software = Software.create(name=name, extension=extension)
    return software.serialize()

def get_software_version(version_id):
    """
    Return entity type maching *name*. If it doesn't exist, it creates it.
    """
    version = SoftwareVersion.get(version_id)
    if version is None:
        raise SoftwareVersionNotFoundException()
    return version.serialize()
    # return base_service.get_instance(
    #     SoftwareVersion, version_id, SoftwareVersionNotFoundException
    # ).serialize()

def get_software_version_template_file(version_id):
    """
    Return entity type maching *name*. If it doesn't exist, it creates it.
    """
    software_version = SoftwareVersion.get(version_id)
    software = software_version.software
    extension = software.extension

    get_local_path = file_store.get_local_file_path
    open_file = file_store.open_file
    file_path = fs.get_file_path_and_file(
        config, get_local_path, open_file, "templates", version_id, extension
    )
    return file_path

def create_template_file(software_version_id, file, extension):
    """
    Get uploaded file then save it in the file storage.
    """
    tmp_folder = current_app.config["TMP_DIR"]
    file_name = software_version_id + '.' + extension
    file_path = os.path.join(tmp_folder, file_name)
    # write binary file to file_path
    with open(file_path, 'wb') as f:
        f.write(file)
    file_store.add_file("templates", software_version_id, file_path)
    os.remove(file_path)
    return file_path

def get_or_create_software_version(software_id, version_name, template_file):
    try:
        software = Software.query.get(software_id)
    except StatementError as ext:
        raise NotFound(ext)
    
    data = {}
    extension = software.extension
    data['software_id'] = software_id
    data['version'] = version_name

    versions = SoftwareVersion.get_all_by(software_id=software.id)
    if versions is None:
        software_version = SoftwareVersion.create(**data)
        software_version.save()
        create_template_file(str(software_version.id), template_file, extension)
        return software_version.serialize()
    
    for v in versions:
        if v.version == version_name:
            return v.serialize()
    
    software_version = SoftwareVersion.create(**data)
    software_version.save()
    create_template_file(str(software_version.id), template_file, extension)
    return software_version.serialize()