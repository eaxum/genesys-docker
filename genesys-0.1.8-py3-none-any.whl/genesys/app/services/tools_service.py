from genesys.app.services import (
    base_service,
)
from genesys.app.models.tool_type import ToolType
from genesys.app.models.tool import Tool
from genesys.app.utils import cache
from genesys.app.services.exception import (
    ToolTypeNotFoundException,
    ToolNotFoundException,
)

@cache.memoize_function(240)
def get_tool_type(tool_type_id):
    """
    Return an tool type matching given id, as a dict. Raises an exception
    if nothing is found.
    """
    return base_service.get_instance(
        ToolType, tool_type_id, ToolTypeNotFoundException
    ).serialize()


@cache.memoize_function(240)
def get_tool_type_by_name(name):
    """
    Return tool type maching *name*. If it doesn't exist, it creates it.
    """
    tool_type = ToolType.get_by(name=name)
    if tool_type is None:
        tool_type = ToolType.create(name=name)
    return tool_type.serialize()


@cache.memoize_function(240)
def get_tool_type_by_name_or_not_found(name):
    """
    Return tool type maching *name*. If it doesn't exist, it creates it.
    """
    tool_type = ToolType.get_by(name=name)
    if tool_type is None:
        raise ToolTypeNotFoundException()
    return tool_type.serialize()


def get_tool_raw(tool_id):
    """
    Return an tool type matching given id, as an active record. Raises an
    exception if nothing is found.
    """
    return base_service.get_instance(
        Tool, tool_id, ToolNotFoundException
    )


@cache.memoize_function(120)
def get_tool(tool_id):
    """
    Return an tool type matching given id, as a dict. Raises an exception if
    nothing is found.
    """
    return base_service.get_instance(
        Tool, tool_id, ToolNotFoundException
    ).serialize()


def clear_tool_cache(tool_id):
    cache.cache.delete_memoized(get_tool, tool_id)


def clear_tool_type_cache(tool_type_id):
    cache.cache.delete_memoized(get_tool_type, tool_type_id)
    cache.cache.delete_memoized(get_tool_type_by_name)


def get_or_create_tool_type(name):
    """
    Return tool type maching *name*. If it doesn't exist, it creates it.
    """
    tool_type = ToolType.get_by(name=name)
    if tool_type is None:
        tool_type = ToolType.create(name=name)
    return tool_type.serialize()