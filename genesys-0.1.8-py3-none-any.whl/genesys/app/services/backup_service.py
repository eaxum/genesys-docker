import datetime
import gzip
import os
import subprocess

from genesys.app.stores import file_store

from flask_fs.backends.local import LocalBackend

from genesys.app import app

template_folder = app.config["TEMPLATE_FOLDER"]
local_file = LocalBackend(
    "local", {"root": os.path.join(template_folder, "files")}
)


def generate_db_backup(host, port, user, password, database):
    """
    Generate a Postgres dump file from the database.
    """
    now = datetime.datetime.now().strftime("%Y-%m-%d")
    filename = "%s-genesys-db-backup.sql.gz" % now
    cmd = ["pg_dump", "-h", host, "-p", port, "-U", user, database]
    with gzip.open(filename, "wb") as f:
        popen = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            universal_newlines=True,
            env={"PGPASSWORD": password},
        )

        for stdout_line in iter(popen.stdout.readline, ""):
            f.write(stdout_line.encode("utf-8"))

        popen.stdout.close()
        popen.wait()

    print(f"Postgres dump created ({filename}).")
    return filename


def store_db_backup(filename):
    """
    Store given file located in the same directory, inside the files bucket
    using the `dbbackup` prefix.
    """
    from genesys.app import app

    with app.app_context():
        file_store.add_file("dbbackup", filename, filename)
