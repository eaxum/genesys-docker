import shutil
import os

from genesys.app.services import (
    base_service,
    entities_service,
    svn_service,
    projects_service,
    softwares_service,
    tasks_service
)
from genesys.app.services.acl_service import ACLParser
from genesys.app.utils import cache

from genesys.app.models.file import File
from genesys.app.models.version_log import VersionLog

from genesys.app.services.exception import (
    FileNotFoundException,
)
from genesys.app.config import (SVN_PARENT_PATH,
                                SVN_PARENT_URL,
                                TEMPLATE_FILES_DIR)
import bpy
from genesys.app import app

def blend_file_gen(blend_file_path):
    dir_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    blender_template_file = os.path.join(dir_path,'template_files', 'blender.blend')
    # file_name = os.path.basename(blend_file_path)
    shutil.copy(blender_template_file, blend_file_path)


def task_directories(working_file_path):
    if working_file_path[0] == '/':
        file_directory = f'{working_file_path[1:]}'
        base_svn_directory = f"{file_directory.split('/', 2)[1]}:/{file_directory.split('/', 2)[2]}"
    else:
        file_directory = f'{working_file_path}'
        base_svn_directory = f"{file_directory.split('/', 3)[2]}:/{file_directory.split('/', 3)[3]}"
    return file_directory, base_svn_directory


def format_file_name(name):
    formated_name = name.replace(' ', '_').lower()
    return formated_name

def get_acl_path(file_path):
    # format is {project_name}:/remaining/path/to/file
    file_path = file_path.strip('/')
    project_name = file_path.split('/')[0]
    remaining_path = file_path.split('/', 1)[1]
    return f'{project_name}:/{remaining_path}'


def clear_file_cache(file_id):
    cache.cache.delete_memoized(get_file, file_id)


def get_file_raw(file_id):
    """
    Return an file type matching given id, as an active record. Raises an
    exception if nothing is found.
    """
    return base_service.get_instance(
        File, file_id, FileNotFoundException
    )


@cache.memoize_function(120)
def get_file(file_id):
    """
    Return an file type matching given id, as a dict. Raises an exception if
    nothing is found.
    """
    return base_service.get_instance(
        File, file_id, FileNotFoundException
    ).serialize()

def get_file_version_log(file_id):
    """
    Return an file type matching given id, as a dict. Raises an exception if
    nothing is found.
    """
    version_log = VersionLog.get_by(file_id=file_id)
    if version_log is None:
        version_log = []
    else:
        version_log = version_log.serialize()
    return version_log

def build_file_name(file, extension):
    """
    Build the file name from the given file.
    """
    suffix = file.suffix
    file_name = file.name
    if suffix:
        file_name = f'{file_name}_{suffix}'
    file_name = f"{format_file_name(file_name)}.{extension}"
    return file_name

def create_default_blend_file(file_path, collection_name, file_data):
    bpy.ops.wm.read_homefile()
    default_collection = bpy.data.collections.get('Collection')
    for obj in default_collection.objects:
        bpy.data.objects.remove(obj, do_unlink=True)
        
    bpy.data.collections.remove(default_collection)
    main_collection = bpy.data.collections.new(collection_name)
    bpy.context.scene.collection.children.link(main_collection)

    # assets = bpy.data.collections.new("assets")
    # main_collection.children.link(assets)

    bpy.data.scenes['Scene'].name = collection_name
    scene = bpy.data.scenes.get(collection_name)
    scene['nagato_file_data'] = file_data
    bpy.ops.wm.save_as_mainfile(filepath=file_path)

def add_file_to_repo(file):
    """
    Add a file to the repository.
    """
    with app.app_context():
        task = tasks_service.get_task_raw(file.task_id)
        entity = entities_service.get_entity_raw(task.entity_id)
        entity_path = entities_service.get_entity_path(entity)
    entity_url = os.path.join(SVN_PARENT_URL, entity_path)
    entity_name = format_file_name(entity.name)
    with app.app_context():
        software_version = softwares_service.get_software_version(file.software_version_id)
    software = software_version['software']
    
    file_name = build_file_name(file, software['extension'])

    file_path = os.path.join(entity_path, file_name)
    file_url = os.path.join(entity_url, file_name)

    if not svn_service.is_svn_url(file_url):
        with app.app_context():
            software_template = softwares_service.get_software_version_template_file(file.software_version_id)
        if software['name'] == 'blender':
            file_data = {
                'collection_name': entity_name,
                'scene_name': entity_name,
                'entity_name': entity_name,
            }
            collection_name = entity_name
            temp_template_file = os.path.join(TEMPLATE_FILES_DIR,'blender.blend')
            #copy software_template to temp_template_file
            shutil.copy(software_template, temp_template_file)
            create_default_blend_file(temp_template_file, collection_name, file_data)
            svn_service.svn_import(path=temp_template_file,
                                    repo_url=file_url,
                                    log_message=f'created {file_url}')
            svn_service.svn_needs_lock(repo_url=file_url,
                                        log_message="set prop to needs lock")
        else:
            svn_service.svn_import(path=software_template,
                                    repo_url=file_url,
                                    log_message=f'created {file_url}')
            svn_service.svn_needs_lock(repo_url=file_url,
                                        log_message="set prop to needs lock")

        svn_acl_entity_path = get_acl_path(file_path)
        with app.app_context():
            project = projects_service.get_project_raw(entity.project_id)
        acl_parser = ACLParser(project_name=project.name)
        acl_parser.add_path(svn_acl_entity_path)
        acl_parser.save()

def set_task_files_permission(task_id, user, permission, dependent_tasks=None):
    """
    Set tasks files permissions.
    """
    with app.app_context():
        task = tasks_service.get_task(task_id, relations=True)
        entity = entities_service.get_entity_raw(task['entity_id'])
        project = projects_service.get_project(entity.project_id)
        entity_path = entities_service.get_entity_path(entity)
    acl_parser = ACLParser(project_name=project['name'])
    for file_id in task['files']:
        with app.app_context():
            file = get_file_raw(file_id)
            software_version = softwares_service.get_software_version(file.software_version_id)
        software = software_version['software']
        file_name = build_file_name(file, software['extension'])
        file_path = os.path.join(entity_path, file_name)
        acl_entity_path = get_acl_path(entity_path)
        acl_parser.give_permission(user, acl_entity_path, permission)
        acl_file_path = get_acl_path(file_path)
        acl_parser.give_permission(user, acl_file_path, permission)
        acl_parser.save()
    if permission == 'none':
        dependency_permission = 'd'
    else:
        dependency_permission = 'r'
    if dependent_tasks:
        for dependent_task_id in dependent_tasks:
            with app.app_context():
                dependent_task = tasks_service.get_task(dependent_task_id, relations=True)
                dependent_entity = entities_service.get_entity_raw(dependent_task['entity_id'])
                dependent_entity_path = entities_service.get_entity_path(dependent_entity)
            for file_id in dependent_task['files']:
                with app.app_context():
                    file = get_file_raw(file_id)
                    software_version = softwares_service.get_software_version(file.software_version_id)
                software = software_version['software']
                file_name = build_file_name(file, software['extension'])
                file_path = os.path.join(dependent_entity_path, file_name)
                acl_entity_path = get_acl_path(dependent_entity_path)
                acl_parser.give_permission(user, acl_entity_path, permission)
                acl_file_path = get_acl_path(file_path)
                acl_parser.give_permission(user, acl_file_path, dependency_permission)
                acl_parser.save()

# def get_or_create_file(name, extension):
#     """
#     Return entity type maching *name*. If it doesn't exist, it creates it.
#     """
#     file = File.get_by(name=name, extension=extension)
#     if file is None:
#         file = File.create(name=name, extension=extension)
#     return file.serialize()
