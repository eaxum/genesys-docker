from genesys.app import app
from genesys.app.utils import dbhelpers


with app.app_context():
    dbhelpers.drop_all()
    dbhelpers.create_all()